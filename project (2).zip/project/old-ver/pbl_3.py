# importing libraries
import csv
import tkinter as tk
from tkinter import Message, Text
import cv2
import os
import shutil
import csv
import numpy as np
from PIL import Image, ImageTk
import pandas as pd
import datetime
import time
import tkinter.ttk as ttk
import tkinter.font as font
from pathlib import Path


def is_number(s):   
	try:
		float(s)
		return True
	except ValueError:
		pass

	try:
		import unicodedata
		unicodedata.numeric(s)
		return True
	except (TypeError, ValueError):
		pass

	return False

def TakeImages():

	Id = int(input("Enter ID: "))
	name = input("Enter Name: ")

	if(name.isalpha()):
		cam = cv2.VideoCapture(0)   #starts capturing video from camera
		harcascadePath = "C:\project\haarcascade_frontalface_default.xml"   
		detector = cv2.CascadeClassifier(harcascadePath)
		sampleNum = 0 
		while(True):
			ret, img = cam.read()
			gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

			# (decreases by 1.3 times) and 5 specifies the
			# number of times scaling happens
			faces = detector.detectMultiScale(gray, 1.3, 5)

			# For creating a rectangle around the image
			for (x, y, w, h) in faces:
				# Specifying the coordinates of the image as well
				# as color and thickness of the rectangle.
				# incrementing sample number for each image
				cv2.rectangle(img, (x, y), (
					x + w, y + h), (255, 0, 0), 2)
				sampleNum = sampleNum + 1
				# saving the captured face in the dataset folder
				# TrainingImage as the image needs to be trained
				# are saved in this folder
				cv2.imwrite(
					"C:\project\TrainingImage\TrainingImage"+name + "."+str(Id) + '.' + str(
						sampleNum) + ".jpg", gray[y:y + h, x:x + w])
				# display the frame that has been captured
				# and drawn rectangle around it.
				cv2.imshow('frame', img)
			# wait for 100 milliseconds
			if cv2.waitKey(100) & 0xFF == ord('q'):
				break
			# break if the sample number is more than 60
			elif sampleNum > 60:
				break
		# releasing the resources
		cam.release()
		# closing all the windows
		cv2.destroyAllWindows()
		# Displaying message for the user
		res = "Images Saved for ID : " + str(Id) + " Name : " + name
		# Creating the entry for the user in a csv file
		row = {"Id":[Id], "Name":[name]}
		df1=pd.DataFrame(row)
		
		if os.path.isfile(r"C:\project\UserDetails.csv"):
			csvfile=open(r"C:\project\UserDetails.csv",mode='r')
			csvreader=csv.reader(csvfile)
			for line in csvreader:
				print(line)
				ind=line[0]
			csvfile.close()
			row1 = {"index":[int(ind)+1],"Id":[Id], "Name":[name]}	
			df2=pd.DataFrame(row1)
			df2.to_csv(r"C:\project\UserDetails.csv", mode='a', index=False, header=False)
			
		else:
			df1.to_csv(r"C:\project\UserDetails.csv", mode='a+', index=True, header=True)
		print(res)
	else:
		if(is_number(Id)):
			res = "Enter Alphabetical Name"
			print(res)
		if(name.isalpha()):
			res = "Enter Numeric Id"
			print(res)
# Training the images saved in training image folder


def TrainImages():
	# Local Binary Pattern Histogram is an Face Recognizer
	# algorithm inside OpenCV module used for training the image dataset
	recognizer = cv2.face.LBPHFaceRecognizer_create()
	# Specifying the path for HaarCascade file
	harcascadePath = "C:\project\haarcascade_frontalface_default.xml"
	# creating detector for faces
	detector = cv2.CascadeClassifier(harcascadePath)
	# Saving the detected faces in variables
	faces, Id = getImagesAndLabels("C:\project\TrainingImage")
	# Saving the trained faces and their respective ID's
	# in a model named as "trainer.yml".
	recognizer.train(faces, np.array(Id))
	recognizer.save(r"C:\project\Trainer.yml")
	# Displaying the message
	res = "Image Trained"
	print(res)


def getImagesAndLabels(path):
	# get the path of all the files in the folder
	imagePaths = [os.path.join(path, f) for f in os.listdir(path)]
	faces = []
	# creating empty ID list
	Ids = []
	# now looping through all the image paths and loading the
	# Ids and the images saved in the folder
	for imagePath in imagePaths:
		# loading the image and converting it to gray scale
		pilImage = Image.open(imagePath).convert('L')
		# Now we are converting the PIL image into numpy array
		imageNp = np.array(pilImage, 'uint8')
		# getting the Id from the image
		Id = int(os.path.split(imagePath)[-1].split(".")[1])
		# extract the face from the training image sample
		faces.append(imageNp)
		Ids.append(Id)
	return faces, Ids
# For testing phase


def TrackImages():
	recognizer = cv2.face.LBPHFaceRecognizer_create()
	# Reading the trained model
	recognizer.read("C:\project\Trainer.yml")
	harcascadePath = "C:\project\haarcascade_frontalface_default.xml"
	faceCascade = cv2.CascadeClassifier(harcascadePath)
	# getting the name from "userdetails.csv"
	df = pd.read_csv(r"C:\project\UserDetails.csv")
	cam = cv2.VideoCapture(0)
	font = cv2.FONT_HERSHEY_SIMPLEX
	while True:
		ret, im = cam.read()
		gray = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)
		faces = faceCascade.detectMultiScale(gray, 1.2, 5)
		for(x, y, w, h) in faces:
			cv2.rectangle(im, (x, y), (x + w, y + h), (225, 0, 0), 2)
			Id, conf = recognizer.predict(gray[y:y + h, x:x + w])
			if(conf < 50):
				aa=df.loc[df["Id"]==Id]['Name'].values
				tt = str(Id)+"-"+aa
			else:
				Id = 'Unknown'
				tt = str(Id)
			if(conf > 75):
				#"C:\project\ImagesUnknown"
				noOfFile = len(os.listdir(r"C:\project\ImagesUnknown"))+1
				cv2.imwrite(r"C:\project\ImagesUnknown\Image" +
							str(noOfFile) + ".jpg", im[y:y + h, x:x + w])
			cv2.putText(im, str(tt), (x, y + h),
						font, 1, (255, 255, 255), 2)
		cv2.imshow('im', im)
		if (cv2.waitKey(1) == ord('q')):
			break
	cam.release()
	cv2.destroyAllWindows()

while True:
	print("1. Take Images")
	print("2. Train Model")
	print("3. Test Facial Recognition")
	print("4. Exit")
	ch=int(input("Enter your Choice:")) 
	if ch==1:
		TakeImages()
	elif ch==2:
		TrainImages()
	elif ch==3:
		TrackImages()
	elif ch==4:
		break
	else:
		print("Invalid Input")
	time.sleep(2)
	os.system('cls')


