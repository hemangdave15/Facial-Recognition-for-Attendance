import pandas as pd;
df=pd.read_csv(r"C:\project\UserDetails.csv")
str=df.to_dict()
print(str)